PHONE BUILD

The easiest phone method is GitHub Actions.

1. Upload this ZIP to your GitHub repository.
2. Keep the repository's .github/workflows/build.yml workflow.
3. Run the workflow from the Actions tab.
4. Download the FakeDoomsdayClient-JAR artifact.

The JAR is produced from the Gradle project inside this ZIP.
