# Fake Doomsday Client

A visual-only Fabric client-style GUI for Minecraft Java Edition 1.21.11.

## Build

Use Java 21 and Gradle 9.3+:

    gradle build

The release JAR is created in `build/libs/`.

For phone builds, the included GitHub Actions workflow can install Gradle and build the project automatically.
